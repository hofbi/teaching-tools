#include <iostream>

int main(int /*argc*/, char** /*argv*/)
{
    std::cout << "Sample code to init the project" << std::endl;

    return EXIT_SUCCESS;
}
